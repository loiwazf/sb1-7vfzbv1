import React from 'react';
import { Shield } from 'lucide-react';
import { Character } from '../types';
import { calculateXPForLevel } from '../utils/levelSystem';

const getTag = (level: number) => {
  if (level === 1) return 'n00b';
  if (level < 5) return 'Apprentice';
  if (level < 10) return 'Adventurer';
  if (level < 15) return 'Veteran';
  if (level < 30) return 'Elite';
  if (level < 50) return 'Master';
  if (level < 80) return 'Grandmaster';
  return 'Legend';
};

const ExpBar: React.FC<{ level: number; exp: number }> = ({ level, exp }) => {
  const requiredXP = calculateXPForLevel(level);
  const percentage = (exp / requiredXP) * 100;
  
  return (
    <div className="w-full bg-gray-800 rounded-full h-2.5 mb-4">
      <div 
        className="bg-yellow-400 h-2.5 rounded-full transition-all duration-500"
        style={{ width: `${percentage}%` }}
      />
      <div className="text-xs text-gray-400 mt-1 text-center">
        {exp} / {requiredXP} XP
      </div>
    </div>
  );
};

const StatBar: React.FC<{ value: number; label: string }> = ({ value, label }) => (
  <div className="mb-2">
    <div className="flex justify-between text-sm mb-1">
      <span className="text-gray-300">{label}</span>
      <span className="text-gray-400">{value}/100</span>
    </div>
    <div className="w-full bg-gray-800 rounded-full h-1.5">
      <div 
        className="bg-gray-500 h-1.5 rounded-full transition-all duration-500"
        style={{ width: `${value}%` }}
      />
    </div>
  </div>
);

interface Props {
  character: Character;
}

export const CharacterPanel: React.FC<Props> = ({ character }) => {
  return (
    <div className="bg-gray-900 rounded-lg p-6 shadow-xl border border-gray-800">
      <div className="flex items-center gap-4 mb-6">
        <Shield className="w-12 h-12 text-gray-400" />
        <div>
          <h2 className="text-2xl font-bold text-white">{character.name}</h2>
          <div className="flex items-center gap-2">
            <span className="text-sm text-gray-400">Level {character.level}</span>
            <span className="px-2 py-1 rounded-full bg-gray-800 text-xs text-gray-300">
              {getTag(character.level)}
            </span>
          </div>
        </div>
      </div>

      <ExpBar level={character.level} exp={character.exp} />

      <div className="space-y-4">
        <StatBar value={character.stats.strength} label="Strength" />
        <StatBar value={character.stats.willpower} label="Willpower" />
        <StatBar value={character.stats.intelligence} label="Intelligence" />
        <StatBar value={character.stats.skill} label="Skill" />
        <StatBar value={character.stats.wisdom} label="Wisdom" />
      </div>
    </div>
  );
}