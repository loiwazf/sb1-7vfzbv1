import React, { useMemo } from 'react';
import { Quest, Goal } from '../types';
import { Calendar, Award } from 'lucide-react';

interface Props {
  completedQuests: Quest[];
  completedGoals: Goal[];
}

interface QuestStreak {
  questId: string;
  questName: string;
  currentStreak: number;
  longestStreak: number;
  lastCompletedDate: string;
}

const calculateStreaks = (quests: Quest[]): Record<string, QuestStreak> => {
  const questsByName: Record<string, Quest[]> = {};
  
  // Group quests by name
  quests.forEach(quest => {
    if (!questsByName[quest.name]) {
      questsByName[quest.name] = [];
    }
    questsByName[quest.name].push(quest);
  });

  const streaks: Record<string, QuestStreak> = {};

  Object.entries(questsByName).forEach(([questName, questList]) => {
    const sortedQuests = questList.sort((a, b) => 
      new Date(b.timestamp!).getTime() - new Date(a.timestamp!).getTime()
    );

    let currentStreak = 0;
    let longestStreak = 0;
    let lastDate = new Date();

    sortedQuests.forEach(quest => {
      const questDate = new Date(quest.timestamp!);
      const diffDays = Math.floor((lastDate.getTime() - questDate.getTime()) / (1000 * 60 * 60 * 24));
      
      if (diffDays <= 1) {
        currentStreak++;
        longestStreak = Math.max(longestStreak, currentStreak);
      } else {
        currentStreak = 1;
      }
      
      lastDate = questDate;
    });

    streaks[questName] = {
      questId: sortedQuests[0].id,
      questName,
      currentStreak,
      longestStreak,
      lastCompletedDate: sortedQuests[0].timestamp!
    };
  });

  return streaks;
};

export const Archive: React.FC<Props> = ({ completedQuests, completedGoals }) => {
  const questsByDate = useMemo(() => {
    const grouped: Record<string, Quest[]> = {};
    completedQuests.forEach(quest => {
      const date = new Date(quest.timestamp!).toLocaleDateString();
      if (!grouped[date]) {
        grouped[date] = [];
      }
      grouped[date].push(quest);
    });
    return grouped;
  }, [completedQuests]);

  const streaks = useMemo(() => 
    calculateStreaks(completedQuests),
    [completedQuests]
  );

  return (
    <div className="space-y-8">
      <div className="bg-gray-800 rounded-lg p-6 shadow-xl border border-gray-700">
        <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
          <Award className="w-6 h-6 text-yellow-400" />
          Quest Streaks
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
          {Object.values(streaks).map(streak => (
            <div
              key={streak.questId}
              className="bg-gray-700 rounded-lg p-4"
            >
              <h3 className="font-medium text-gray-200 mb-2">{streak.questName}</h3>
              <div className="space-y-1 text-sm">
                <p className="text-blue-400">Current Streak: {streak.currentStreak} days</p>
                <p className="text-yellow-400">Longest Streak: {streak.longestStreak} days</p>
                <p className="text-gray-400">
                  Last completed: {new Date(streak.lastCompletedDate).toLocaleDateString()}
                </p>
              </div>
            </div>
          ))}
        </div>

        <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
          <Calendar className="w-5 h-5 text-blue-400" />
          Completion History
        </h3>
        <div className="space-y-6">
          {Object.entries(questsByDate).sort((a, b) => 
            new Date(b[0]).getTime() - new Date(a[0]).getTime()
          ).map(([date, quests]) => (
            <div key={date} className="space-y-3">
              <h4 className="text-sm font-medium text-gray-400">{date}</h4>
              <div className="space-y-2">
                {quests.map((quest) => (
                  <div
                    key={`${quest.id}-${quest.timestamp}`}
                    className="p-3 rounded-lg bg-gray-700 flex justify-between items-center"
                  >
                    <span className="text-gray-200">{quest.name}</span>
                    <div className="flex items-center gap-4">
                      <span className="text-yellow-400">+{quest.xp} XP</span>
                      <span className="text-sm text-gray-400">
                        {new Date(quest.timestamp!).toLocaleTimeString()}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-gray-800 rounded-lg p-6 shadow-xl border border-gray-700">
        <h2 className="text-xl font-bold text-white mb-4">Completed Goals</h2>
        <div className="space-y-3">
          {completedGoals.map((goal) => (
            <div
              key={goal.id}
              className="p-4 rounded-lg bg-gray-700"
            >
              <div className="flex justify-between items-center mb-2">
                <h3 className="font-medium text-gray-200">{goal.title}</h3>
                <div className="text-sm">
                  <span className="text-gray-400">Created: </span>
                  <span className="text-gray-300">{new Date(goal.createdAt).toLocaleDateString()}</span>
                  <span className="text-gray-400 ml-4">Completed: </span>
                  <span className="text-gray-300">{new Date(goal.completedAt!).toLocaleDateString()}</span>
                </div>
              </div>
              <p className="text-sm text-gray-400 mb-2">{goal.description}</p>
              <div className="flex items-center gap-3">
                <span className="text-xs px-2 py-1 rounded-full bg-gray-600 text-gray-300">
                  {goal.type}
                </span>
                <span className="text-xs px-2 py-1 rounded-full bg-gray-600 text-gray-300">
                  {goal.statType}
                </span>
                <span className="text-yellow-400 text-sm">+{goal.xp} XP</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};