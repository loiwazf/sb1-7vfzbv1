import React, { useState } from 'react';
import { Plus, X, RotateCcw, Trash2 } from 'lucide-react';
import { Goal, Character } from '../types';

interface Props {
  title: string;
  type: 'weekly' | 'monthly';
  goals: Goal[];
  onAddGoal: (goal: Omit<Goal, 'id' | 'completed' | 'createdAt' | 'completedAt'>) => void;
  onCompleteGoal: (goalId: string) => void;
  onDeleteGoal: (goalId: string) => void;
  onReset: () => void;
}

export const GoalsList: React.FC<Props> = ({
  title,
  type,
  goals,
  onAddGoal,
  onCompleteGoal,
  onDeleteGoal,
  onReset,
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newGoal, setNewGoal] = useState({
    title: '',
    description: '',
    statType: 'strength' as keyof Character['stats'],
    xp: 50,
    dueDate: new Date().toISOString().split('T')[0]
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAddGoal({
      title: newGoal.title,
      description: newGoal.description,
      type,
      statType: newGoal.statType,
      xp: newGoal.xp,
      dueDate: new Date(newGoal.dueDate).toISOString()
    });
    setNewGoal({ title: '', description: '', statType: 'strength', xp: 50, dueDate: new Date().toISOString().split('T')[0] });
    setIsModalOpen(false);
  };

  const isOverdue = (dueDate: string) => {
    return new Date(dueDate) < new Date();
  };

  return (
    <>
      <div className="bg-gray-900 rounded-lg p-6 shadow-xl border border-gray-800">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-white">{title}</h2>
          <div className="flex gap-2">
            <button
              onClick={onReset}
              className="p-2 rounded-lg bg-red-600 hover:bg-red-700 transition-colors"
              title={`Reset ${type}`}
            >
              <RotateCcw className="w-5 h-5" />
            </button>
            <button
              onClick={() => setIsModalOpen(true)}
              className="p-2 rounded-lg bg-gray-700 hover:bg-gray-600 transition-colors"
            >
              <Plus className="w-5 h-5" />
            </button>
          </div>
        </div>
        <div className="space-y-3">
          {goals.map((goal) => (
            <div
              key={goal.id}
              className={`p-4 rounded-lg bg-gray-800 hover:bg-gray-700 transition-colors ${
                isOverdue(goal.dueDate) && !goal.completed ? 'border-l-4 border-red-500' : ''
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-medium text-gray-200">{goal.title}</h3>
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => onDeleteGoal(goal.id)}
                    className="text-gray-400 hover:text-red-400 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                  <input
                    type="checkbox"
                    checked={goal.completed}
                    onChange={() => onCompleteGoal(goal.id)}
                    className="w-4 h-4 rounded border-gray-600"
                  />
                </div>
              </div>
              <p className="text-sm text-gray-400 mb-2">{goal.description}</p>
              <div className="flex items-center gap-3 text-sm">
                <span className="px-2 py-1 rounded-full bg-gray-700 text-gray-300">
                  {goal.statType}
                </span>
                <span className="text-yellow-400">+{goal.xp} XP</span>
                <span className={`text-xs ${
                  isOverdue(goal.dueDate) && !goal.completed ? 'text-red-400' : 'text-gray-400'
                }`}>
                  Due: {new Date(goal.dueDate).toLocaleDateString()}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <div className="bg-gray-900 rounded-lg p-6 w-full max-w-md">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-bold text-white">Add New Goal</h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-gray-400 hover:text-gray-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">
                  Title
                </label>
                <input
                  type="text"
                  value={newGoal.title}
                  onChange={(e) => setNewGoal({ ...newGoal, title: e.target.value })}
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">
                  Description
                </label>
                <textarea
                  value={newGoal.description}
                  onChange={(e) => setNewGoal({ ...newGoal, description: e.target.value })}
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white"
                  rows={3}
                  required
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-1">
                    Related Stat
                  </label>
                  <select
                    value={newGoal.statType}
                    onChange={(e) => setNewGoal({ ...newGoal, statType: e.target.value as keyof Character['stats'] })}
                    className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white"
                  >
                    <option value="strength">Strength</option>
                    <option value="willpower">Willpower</option>
                    <option value="intelligence">Intelligence</option>
                    <option value="skill">Skill</option>
                    <option value="wisdom">Wisdom</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-1">
                    XP Reward
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={newGoal.xp}
                    onChange={(e) => setNewGoal({ ...newGoal, xp: parseInt(e.target.value) })}
                    className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white"
                    required
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">
                  Due Date
                </label>
                <input
                  type="date"
                  value={newGoal.dueDate}
                  onChange={(e) => setNewGoal({ ...newGoal, dueDate: e.target.value })}
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white"
                  required
                />
              </div>
              <button
                type="submit"
                className="w-full bg-gray-700 hover:bg-gray-600 text-white font-medium py-2 px-4 rounded-lg transition-colors"
              >
                Add Goal
              </button>
            </form>
          </div>
        </div>
      )}
    </>
  );
}