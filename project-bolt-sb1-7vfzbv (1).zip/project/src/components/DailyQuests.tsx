import React from 'react';
import { CheckCircle, Circle } from 'lucide-react';
import { Quest } from '../types';

interface Props {
  quests: Quest[];
  onCompleteQuest: (questId: string) => void;
}

export const DailyQuests: React.FC<Props> = ({ quests, onCompleteQuest }) => {
  return (
    <div className="bg-gray-900 rounded-lg p-6 shadow-xl border border-gray-800">
      <h2 className="text-xl font-bold text-white mb-4">Daily Quests</h2>
      <div className="space-y-3">
        {quests.map((quest) => (
          <div
            key={quest.id}
            className="flex items-center justify-between p-3 rounded-lg bg-gray-800 hover:bg-gray-700 transition-colors"
          >
            <div className="flex items-center gap-3">
              <button
                onClick={() => onCompleteQuest(quest.id)}
                className="text-gray-400 hover:text-gray-300 transition-colors"
              >
                {quest.completed ? (
                  <CheckCircle className="w-6 h-6 text-green-400" />
                ) : (
                  <Circle className="w-6 h-6" />
                )}
              </button>
              <span className="text-gray-200">{quest.name}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-yellow-400 text-sm">+{quest.xp} XP</span>
              <span className="text-xs text-gray-400">({quest.statType})</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}