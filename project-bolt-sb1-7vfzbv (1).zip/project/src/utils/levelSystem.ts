// For level 1, need 200 XP
// Increases by 25 XP per level
export const calculateXPForLevel = (level: number): number => {
  return 200 + (level - 1) * 25;
};

export const calculateTotalXPForLevel = (targetLevel: number): number => {
  let total = 0;
  for (let level = 1; level < targetLevel; level++) {
    total += calculateXPForLevel(level);
  }
  return total;
};

export const calculateLevelFromXP = (totalXP: number): { level: number; remainingXP: number } => {
  let level = 1;
  let remainingXP = totalXP;
  
  while (remainingXP >= calculateXPForLevel(level) && level < 80) {
    remainingXP -= calculateXPForLevel(level);
    level++;
  }
  
  return { level, remainingXP };
};