export interface Character {
  name: string;
  level: number;
  exp: number;
  stats: {
    strength: number;
    willpower: number;
    intelligence: number;
    skill: number;
    wisdom: number;
  };
}

export interface Quest {
  id: string;
  name: string;
  xp: number;
  statType: keyof Character['stats'];
  completed: boolean;
  timestamp?: string;
}

export interface Goal {
  id: string;
  title: string;
  description: string;
  type: 'weekly' | 'monthly';
  statType: keyof Character['stats'];
  xp: number;
  completed: boolean;
  createdAt: string;
  completedAt?: string;
  dueDate: string;
}