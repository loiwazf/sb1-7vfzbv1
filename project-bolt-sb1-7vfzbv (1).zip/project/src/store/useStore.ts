import { create } from 'zustand';
import { supabase } from '../lib/supabase';
import { Character, Quest, Goal } from '../types';

interface State {
  user: any | null;
  character: Character | null;
  quests: Quest[];
  weeklyGoals: Goal[];
  monthlyGoals: Goal[];
  isLoading: boolean;
  error: string | null;
  
  // Auth actions
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  
  // Data fetching
  fetchCharacter: () => Promise<void>;
  fetchQuests: () => Promise<void>;
  fetchGoals: () => Promise<void>;
  
  // Data mutations
  updateCharacter: (updates: Partial<Character>) => Promise<void>;
  completeQuest: (questId: string) => Promise<void>;
  addGoal: (goal: Omit<Goal, 'id' | 'completed' | 'createdAt' | 'completedAt'>) => Promise<void>;
  completeGoal: (goalId: string) => Promise<void>;
  deleteGoal: (goalId: string) => Promise<void>;
  resetDay: () => Promise<void>;
  resetWeek: () => Promise<void>;
  resetMonth: () => Promise<void>;
}

export const useStore = create<State>((set, get) => ({
  user: null,
  character: null,
  quests: [],
  weeklyGoals: [],
  monthlyGoals: [],
  isLoading: false,
  error: null,

  login: async (email: string, password: string) => {
    try {
      set({ isLoading: true, error: null });
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });
      if (error) throw error;
      set({ user: data.user });
      await get().fetchCharacter();
      await get().fetchQuests();
      await get().fetchGoals();
    } catch (error: any) {
      set({ error: error.message });
    } finally {
      set({ isLoading: false });
    }
  },

  logout: async () => {
    await supabase.auth.signOut();
    set({
      user: null,
      character: null,
      quests: [],
      weeklyGoals: [],
      monthlyGoals: [],
    });
  },

  fetchCharacter: async () => {
    const { user } = get();
    if (!user) return;

    try {
      set({ isLoading: true, error: null });
      const { data, error } = await supabase
        .from('characters')
        .select('*')
        .eq('user_id', user.id)
        .single();

      if (error) throw error;
      set({ character: data });
    } catch (error: any) {
      set({ error: error.message });
    } finally {
      set({ isLoading: false });
    }
  },

  fetchQuests: async () => {
    const { user } = get();
    if (!user) return;

    try {
      set({ isLoading: true, error: null });
      const { data, error } = await supabase
        .from('daily_quests')
        .select('*')
        .eq('user_id', user.id);

      if (error) throw error;
      set({ quests: data });
    } catch (error: any) {
      set({ error: error.message });
    } finally {
      set({ isLoading: false });
    }
  },

  fetchGoals: async () => {
    const { user } = get();
    if (!user) return;

    try {
      set({ isLoading: true, error: null });
      const { data, error } = await supabase
        .from('goals')
        .select('*')
        .eq('user_id', user.id);

      if (error) throw error;

      const weekly = data?.filter(goal => goal.type === 'weekly') || [];
      const monthly = data?.filter(goal => goal.type === 'monthly') || [];
      
      set({ weeklyGoals: weekly, monthlyGoals: monthly });
    } catch (error: any) {
      set({ error: error.message });
    } finally {
      set({ isLoading: false });
    }
  },

  updateCharacter: async (updates) => {
    const { user, character } = get();
    if (!user || !character) return;

    try {
      set({ isLoading: true, error: null });
      const { error } = await supabase
        .from('characters')
        .update(updates)
        .eq('user_id', user.id);

      if (error) throw error;
      set({ character: { ...character, ...updates } });
    } catch (error: any) {
      set({ error: error.message });
    } finally {
      set({ isLoading: false });
    }
  },

  completeQuest: async (questId) => {
    const { user, quests, character } = get();
    if (!user || !character) return;

    const quest = quests.find(q => q.id === questId);
    if (!quest) return;

    try {
      set({ isLoading: true, error: null });
      const newCompleted = !quest.completed;
      
      const { error } = await supabase
        .from('daily_quests')
        .update({
          completed: newCompleted,
          completed_at: newCompleted ? new Date().toISOString() : null,
        })
        .eq('id', questId);

      if (error) throw error;

      // Update character stats and exp
      const expChange = newCompleted ? quest.xp : -quest.xp;
      const statChange = newCompleted ? 1 : -1;
      
      const newStats = { ...character.stats };
      newStats[quest.statType] = Math.max(1, Math.min(100, newStats[quest.statType] + statChange));
      
      await get().updateCharacter({
        exp: Math.max(0, character.exp + expChange),
        stats: newStats,
      });

      set({
        quests: quests.map(q =>
          q.id === questId
            ? { ...q, completed: newCompleted }
            : q
        ),
      });
    } catch (error: any) {
      set({ error: error.message });
    } finally {
      set({ isLoading: false });
    }
  },

  addGoal: async (goalData) => {
    const { user } = get();
    if (!user) return;

    try {
      set({ isLoading: true, error: null });
      const { data, error } = await supabase
        .from('goals')
        .insert([{
          ...goalData,
          user_id: user.id,
          completed: false,
        }])
        .select()
        .single();

      if (error) throw error;

      if (goalData.type === 'weekly') {
        set(state => ({
          weeklyGoals: [...state.weeklyGoals, data],
        }));
      } else {
        set(state => ({
          monthlyGoals: [...state.monthlyGoals, data],
        }));
      }
    } catch (error: any) {
      set({ error: error.message });
    } finally {
      set({ isLoading: false });
    }
  },

  completeGoal: async (goalId) => {
    const { user, weeklyGoals, monthlyGoals, character } = get();
    if (!user || !character) return;

    const goal = [...weeklyGoals, ...monthlyGoals].find(g => g.id === goalId);
    if (!goal) return;

    try {
      set({ isLoading: true, error: null });
      const newCompleted = !goal.completed;
      
      const { error } = await supabase
        .from('goals')
        .update({
          completed: newCompleted,
          completed_at: newCompleted ? new Date().toISOString() : null,
        })
        .eq('id', goalId);

      if (error) throw error;

      // Update character stats and exp
      const expChange = newCompleted ? goal.xp : -goal.xp;
      const statChange = newCompleted ? (goal.type === 'weekly' ? 2 : 3) : (goal.type === 'weekly' ? -2 : -3);
      
      const newStats = { ...character.stats };
      newStats[goal.statType] = Math.max(1, Math.min(100, newStats[goal.statType] + statChange));
      
      await get().updateCharacter({
        exp: Math.max(0, character.exp + expChange),
        stats: newStats,
      });

      if (goal.type === 'weekly') {
        set({
          weeklyGoals: weeklyGoals.map(g =>
            g.id === goalId ? { ...g, completed: newCompleted } : g
          ),
        });
      } else {
        set({
          monthlyGoals: monthlyGoals.map(g =>
            g.id === goalId ? { ...g, completed: newCompleted } : g
          ),
        });
      }
    } catch (error: any) {
      set({ error: error.message });
    } finally {
      set({ isLoading: false });
    }
  },

  deleteGoal: async (goalId) => {
    const { user } = get();
    if (!user) return;

    try {
      set({ isLoading: true, error: null });
      const { error } = await supabase
        .from('goals')
        .delete()
        .eq('id', goalId);

      if (error) throw error;

      set(state => ({
        weeklyGoals: state.weeklyGoals.filter(g => g.id !== goalId),
        monthlyGoals: state.monthlyGoals.filter(g => g.id !== goalId),
      }));
    } catch (error: any) {
      set({ error: error.message });
    } finally {
      set({ isLoading: false });
    }
  },

  resetDay: async () => {
    const { user } = get();
    if (!user) return;

    try {
      set({ isLoading: true, error: null });
      const { error } = await supabase
        .from('daily_quests')
        .update({ completed: false, completed_at: null })
        .eq('user_id', user.id);

      if (error) throw error;
      await get().fetchQuests();
    } catch (error: any) {
      set({ error: error.message });
    } finally {
      set({ isLoading: false });
    }
  },

  resetWeek: async () => {
    const { user } = get();
    if (!user) return;

    try {
      set({ isLoading: true, error: null });
      const { error } = await supabase
        .from('goals')
        .delete()
        .eq('user_id', user.id)
        .eq('type', 'weekly');

      if (error) throw error;
      set({ weeklyGoals: [] });
    } catch (error: any) {
      set({ error: error.message });
    } finally {
      set({ isLoading: false });
    }
  },

  resetMonth: async () => {
    const { user } = get();
    if (!user) return;

    try {
      set({ isLoading: true, error: null });
      const { error } = await supabase
        .from('goals')
        .delete()
        .eq('user_id', user.id)
        .eq('type', 'monthly');

      if (error) throw error;
      set({ monthlyGoals: [] });
    } catch (error: any) {
      set({ error: error.message });
    } finally {
      set({ isLoading: false });
    }
  },
}));