export interface Database {
  public: {
    Tables: {
      characters: {
        Row: {
          id: string;
          user_id: string;
          name: string;
          level: number;
          exp: number;
          stats: {
            strength: number;
            willpower: number;
            intelligence: number;
            skill: number;
            wisdom: number;
          };
          created_at: string;
          updated_at: string;
        };
        Insert: Omit<Database['public']['Tables']['characters']['Row'], 'id' | 'created_at' | 'updated_at'>;
        Update: Partial<Omit<Database['public']['Tables']['characters']['Row'], 'id'>>;
      };
      daily_quests: {
        Row: {
          id: string;
          user_id: string;
          name: string;
          xp: number;
          stat_type: string;
          completed: boolean;
          completed_at: string | null;
          created_at: string;
        };
        Insert: Omit<Database['public']['Tables']['daily_quests']['Row'], 'id' | 'created_at'>;
        Update: Partial<Omit<Database['public']['Tables']['daily_quests']['Row'], 'id'>>;
      };
      goals: {
        Row: {
          id: string;
          user_id: string;
          title: string;
          description: string;
          type: 'weekly' | 'monthly';
          stat_type: string;
          xp: number;
          completed: boolean;
          due_date: string;
          completed_at: string | null;
          created_at: string;
        };
        Insert: Omit<Database['public']['Tables']['goals']['Row'], 'id' | 'created_at'>;
        Update: Partial<Omit<Database['public']['Tables']['goals']['Row'], 'id'>>;
      };
    };
  };
}