import React, { useState, useEffect } from 'react';
import { CharacterPanel } from './components/CharacterPanel';
import { DailyQuests } from './components/DailyQuests';
import { GoalsList } from './components/GoalsList';
import { Archive } from './components/Archive';
import { Character, Quest, Goal } from './types';
import { v4 as uuidv4 } from 'uuid';
import { calculateLevelFromXP } from './utils/levelSystem';

const DEFAULT_CHARACTER: Character = {
  name: 'maedre',
  level: 1,
  exp: 0,
  stats: {
    strength: 1,
    willpower: 1,
    intelligence: 1,
    skill: 1,
    wisdom: 1,
  },
};

const DEFAULT_QUESTS: Quest[] = [
  {
    id: '1',
    name: 'Journal',
    xp: 50,
    statType: 'wisdom',
    completed: false,
  },
  {
    id: '2',
    name: 'Meditation',
    xp: 50,
    statType: 'willpower',
    completed: false,
  },
  {
    id: '3',
    name: 'Design',
    xp: 150,
    statType: 'skill',
    completed: false,
  },
  {
    id: '4',
    name: 'Workout',
    xp: 75,
    statType: 'strength',
    completed: false,
  },
  {
    id: '5',
    name: 'Reading',
    xp: 50,
    statType: 'intelligence',
    completed: false,
  },
];

function App() {
  const [character, setCharacter] = useState<Character>(DEFAULT_CHARACTER);
  const [quests, setQuests] = useState<Quest[]>(DEFAULT_QUESTS);
  const [weeklyGoals, setWeeklyGoals] = useState<Goal[]>([]);
  const [monthlyGoals, setMonthlyGoals] = useState<Goal[]>([]);
  const [completedQuests, setCompletedQuests] = useState<Quest[]>([]);
  const [completedGoals, setCompletedGoals] = useState<Goal[]>([]);
  const [activeTab, setActiveTab] = useState<'main' | 'archive'>('main');

  const handleCompleteQuest = (questId: string) => {
    const quest = quests.find((q) => q.id === questId);
    if (!quest) return;

    const newCompleted = !quest.completed;
    const updatedQuests = quests.map((q) =>
      q.id === questId
        ? {
            ...q,
            completed: newCompleted,
            timestamp: newCompleted ? new Date().toISOString() : undefined,
          }
        : q
    );

    const newStats = { ...character.stats };
    const newTotalXP = character.exp + (newCompleted ? quest.xp : -quest.xp);
    
    newStats[quest.statType] = Math.max(
      1,
      Math.min(
        100,
        newStats[quest.statType] + (newCompleted ? 1 : -1)
      )
    );

    const { level, remainingXP } = calculateLevelFromXP(Math.max(0, newTotalXP));

    setCharacter({
      ...character,
      level,
      exp: remainingXP,
      stats: newStats,
    });

    if (newCompleted) {
      setCompletedQuests([
        ...completedQuests,
        { ...quest, completed: true, timestamp: new Date().toISOString() },
      ]);
    } else {
      setCompletedQuests(completedQuests.filter((q) => q.id !== questId));
    }

    setQuests(updatedQuests);
  };

  const handleAddGoal = (
    goalData: Omit<Goal, 'id' | 'completed' | 'createdAt' | 'completedAt'>
  ) => {
    const newGoal: Goal = {
      ...goalData,
      id: uuidv4(),
      completed: false,
      createdAt: new Date().toISOString(),
    };

    if (goalData.type === 'weekly') {
      setWeeklyGoals([...weeklyGoals, newGoal]);
    } else {
      setMonthlyGoals([...monthlyGoals, newGoal]);
    }
  };

  const handleDeleteGoal = (goalId: string) => {
    setWeeklyGoals(weeklyGoals.filter(g => g.id !== goalId));
    setMonthlyGoals(monthlyGoals.filter(g => g.id !== goalId));
  };

  const handleCompleteGoal = (goalId: string) => {
    const processGoals = (goals: Goal[]) => {
      const goal = goals.find((g) => g.id === goalId);
      if (!goal) return { updatedGoals: goals, completedGoal: null };

      const newCompleted = !goal.completed;
      const updatedGoals = goals.map((g) =>
        g.id === goalId
          ? {
              ...g,
              completed: newCompleted,
              completedAt: newCompleted ? new Date().toISOString() : undefined,
            }
          : g
      );

      return {
        updatedGoals,
        completedGoal: newCompleted ? { ...goal, completed: true, completedAt: new Date().toISOString() } : null,
        originalGoal: goal,
      };
    };

    const weeklyResult = processGoals(weeklyGoals);
    const monthlyResult = processGoals(monthlyGoals);

    if (weeklyResult.originalGoal) {
      setWeeklyGoals(weeklyResult.updatedGoals);
      const goal = weeklyResult.originalGoal;
      const newCompleted = !goal.completed;

      if (newCompleted) {
        setCompletedGoals([...completedGoals, { ...goal, completed: true, completedAt: new Date().toISOString() }]);
      } else {
        setCompletedGoals(completedGoals.filter((g) => g.id !== goal.id));
      }

      const newStats = { ...character.stats };
      const newTotalXP = character.exp + (newCompleted ? goal.xp : -goal.xp);
      
      newStats[goal.statType] = Math.max(
        1,
        Math.min(
          100,
          newStats[goal.statType] + (newCompleted ? 2 : -2)
        )
      );

      const { level, remainingXP } = calculateLevelFromXP(Math.max(0, newTotalXP));

      setCharacter({
        ...character,
        level,
        exp: remainingXP,
        stats: newStats,
      });
    }

    if (monthlyResult.originalGoal) {
      setMonthlyGoals(monthlyResult.updatedGoals);
      const goal = monthlyResult.originalGoal;
      const newCompleted = !goal.completed;

      if (newCompleted) {
        setCompletedGoals([...completedGoals, { ...goal, completed: true, completedAt: new Date().toISOString() }]);
      } else {
        setCompletedGoals(completedGoals.filter((g) => g.id !== goal.id));
      }

      const newStats = { ...character.stats };
      const newTotalXP = character.exp + (newCompleted ? goal.xp : -goal.xp);
      
      newStats[goal.statType] = Math.max(
        1,
        Math.min(
          100,
          newStats[goal.statType] + (newCompleted ? 3 : -3)
        )
      );

      const { level, remainingXP } = calculateLevelFromXP(Math.max(0, newTotalXP));

      setCharacter({
        ...character,
        level,
        exp: remainingXP,
        stats: newStats,
      });
    }
  };

  const resetDay = () => {
    setQuests(DEFAULT_QUESTS);
  };

  const resetWeek = () => {
    setWeeklyGoals([]);
  };

  const resetMonth = () => {
    setMonthlyGoals([]);
  };

  return (
    <div className="min-h-screen bg-black text-white p-6">
      <div className="max-w-6xl mx-auto">
        <div className="flex justify-end items-center mb-8">
          <div className="space-x-4">
            <button
              onClick={() => setActiveTab('main')}
              className={`px-4 py-2 rounded-lg transition-colors ${
                activeTab === 'main'
                  ? 'bg-gray-700'
                  : 'bg-gray-800 hover:bg-gray-700'
              }`}
            >
              Main
            </button>
            <button
              onClick={() => setActiveTab('archive')}
              className={`px-4 py-2 rounded-lg transition-colors ${
                activeTab === 'archive'
                  ? 'bg-gray-700'
                  : 'bg-gray-800 hover:bg-gray-700'
              }`}
            >
              Archive
            </button>
          </div>
        </div>

        {activeTab === 'main' ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-6">
              <CharacterPanel character={character} />
              <DailyQuests quests={quests} onCompleteQuest={handleCompleteQuest} />
              <button
                onClick={resetDay}
                className="w-full py-2 bg-red-600 hover:bg-red-700 rounded-lg transition-colors"
              >
                Reset Day
              </button>
            </div>
            <div className="space-y-6">
              <GoalsList
                title="Weekly Goals"
                type="weekly"
                goals={weeklyGoals}
                onAddGoal={handleAddGoal}
                onCompleteGoal={handleCompleteGoal}
                onDeleteGoal={handleDeleteGoal}
                onReset={resetWeek}
              />
              <GoalsList
                title="Monthly Goals"
                type="monthly"
                goals={monthlyGoals}
                onAddGoal={handleAddGoal}
                onCompleteGoal={handleCompleteGoal}
                onDeleteGoal={handleDeleteGoal}
                onReset={resetMonth}
              />
            </div>
          </div>
        ) : (
          <Archive completedQuests={completedQuests} completedGoals={completedGoals} />
        )}
      </div>
    </div>
  );
}

export default App;